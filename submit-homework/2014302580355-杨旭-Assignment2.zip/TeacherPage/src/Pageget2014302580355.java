import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
  

import java.io.PrintWriter;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
  
  public class Pageget2014302580355 {
    
     public  Document getDocument (String url){
         try {
             return Jsoup.connect(url).get();
         } catch (IOException e) {
             e.printStackTrace();
         }
         return null;
     }
     public static void main(String[] args) throws IOException {
    	 Pageget2014302580355 t = new Pageget2014302580355();
         Document doc = t.getDocument("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Zha Quan Xing");
         // ��ȡĿ��HTML����
         Elements elements1 = doc.select("[class=title]");
         Elements elements2 = elements1.select("h3");
         String name = elements2.get(0).text();
         System.out.println(name);

         Element elements3 = doc.select("[class=szll_wz][style=OVERFLOW: hidden; BORDER-TOP: rgb(51,51,51) 1px solid; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; COLOR: rgb(0,0,0); PADDING-BOTTOM: 0px; TEXT-ALIGN: left; PADDING-TOP: 10px; FONT: 12px Simsun; PADDING-LEFT: 0px; CLEAR: both; MARGIN: 10px 0px 0px; LETTER-SPACING: normal; PADDING-RIGHT: 0px; BACKGROUND-COLOR: rgb(255,255,255); TEXT-INDENT: 0px; -webkit-text-stroke-width: 0px]").first();
         String intro=elements3.text(); 
         System.out.println(intro);
         
         Elements elements4=doc.select("p:matches(\\d{3}-\\d{8})");
         Elements elements5=elements4.select("p:contains(�о�����)");
         String line=elements5.text();
         String str1 = "",str2="",str3="";
         String[] strarray=line.split("");
         for(int i=8;i<24;i++){
         str1=str1+strarray[i];}
         System.out.println(str1);
         for(int i=25;i<43;i++){
         str2=str2+strarray[i];}
         System.out.println(str2);
         for(int i=44;i<strarray.length;i++){
         str3=str3+strarray[i];}
         System.out.println(str3);
         
        PrintWriter pw = new PrintWriter( new FileWriter( "��ʦ��ҳ����.txt" ) );
        pw.print("����:"+name+"\r\n");
        pw.print("���˾���:"+intro+"\r\n");
        pw.print(str1+"\r\n");
        pw.print(str2+"\r\n");
        pw.print(str3+"\r\n");
        pw.close( );

     }
 }