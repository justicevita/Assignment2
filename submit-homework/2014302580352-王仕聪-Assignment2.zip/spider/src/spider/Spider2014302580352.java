package spider;


import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Spider2014302580352 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Document doc = Jsoup.connect("http://my.chd.edu.cn/pei").get();
		String title = doc.title();
		Elements content=doc.select(".boder.h225");

		String linkText = content.text().replace(Jsoup.parse("&nbsp;").text(), " ");//����&nbsp���ʺ���������
		String email1=null,email2=null,call=null;
		Pattern p=Pattern.compile("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+");//�������ʽѡ������
		Matcher m=p.matcher(linkText);
		for(int i=0;m.find();i++){
			if(i==0){
				email1=m.group();			
			}
			else{
				email2=m.group();
			}
		}

		Pattern p1=Pattern.compile("(\\(\\d{3,4}\\)|\\d{3,4}-|\\s)?\\d{7,14}");//�������ʽѡ�ֻ�����
		Matcher m1=p1.matcher(linkText);
		while(m1.find()){
			call=m1.group();
		}
		String linkText1=linkText.substring(160,690);
		linkText1="���˼�飺"+linkText1;
		String linkText2=linkText.substring(691,890);
		linkText2=linkText.substring(691,697)+":"+linkText.substring(698,890);

		FileWriter writer=new FileWriter("spider.txt");//���TXT�ļ�
		String name="������"+linkText.substring(160,163);
		writer.write(name);
		writer.write("\r\n");//���пո�
		writer.write("\r\n");
		writer.write(linkText1);
		writer.write("\r\n");//���пո�
		writer.write("\r\n");
		writer.write(linkText2);
		writer.write("\r\n");
		writer.write("\r\n");
		writer.write("���䣺");
		writer.write(email1);
		writer.write("\r\n");//���пո�
		writer.write(email2);
		writer.write("\r\n");//���пո�
		writer.write("\r\n");
		writer.write("�绰���룺");
		writer.write(call);
		writer.flush();
		writer.close();
	}

}
